class Bekasi:
    def __init__(self, nama, telp, alamat, jenis):
        super().__init__("Bekasi", telp, alamat)
        self.nama = nama
        self.telp = telp

    def nama(self):
        return "Annisa Khansa" + self.nama + "."

    def nama(self):
        return self.nama

    